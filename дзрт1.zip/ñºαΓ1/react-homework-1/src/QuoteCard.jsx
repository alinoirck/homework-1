function QuoteCard() {
  const quoteText = "Кайфуйте, жизнь одна!";
  const author = "Ольга Бузова";

  return (
    <blockquote className="quote-card">
      <p>{quoteText}</p>
      <footer>{author}</footer>
    </blockquote>
  );
}

export default QuoteCard