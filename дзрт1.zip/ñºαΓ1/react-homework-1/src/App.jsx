import QuoteCard from "./QuoteCard";
import "./App.css";

function App() {
  return (
    <div>
      <QuoteCard />
      <QuoteCard />
      <QuoteCard />
    </div>
  );
}


export default App


